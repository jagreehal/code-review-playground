---
title: Reference
description: Every step marker, doc method, reporter option, CLI flag, and type, per adapter.
slug: reference
---

> **Looking for how, not what?**
The [guides](/guides/) are task-shaped. This section is the exhaustive surface: signatures, options, and flags.

## Story and doc API

The same story structure and doc model in every adapter. Where a host framework forces a difference, the page says so.

  - [Vitest](/reference/vitest-story-api/)
  - [Jest](/reference/jest-story-api/)
  - [Playwright](/reference/playwright-story-api/)
  - [Cypress](/reference/cypress-story-api/)
  - [e2e](/reference/e2e/)
  - [Ruby](/reference/ruby-story-api/)
  - [Go, Python, Rust, Kotlin, C#](/reference/other-adapters/)

## Reporter options

  - [Vitest reporter](/reference/vitest-config/)
  - [Jest reporter](/reference/jest-config/)
  - [Playwright reporter](/reference/playwright-config/)
  - [Cypress reporter](/reference/cypress-config/)

## CLI, packages, and types

  - [Formatters API and CLI](/reference/formatters-api/)
  - [Package map](/reference/package-map/)
  - [Core types and constants](/reference/core-api/)
  - [Cross-language parity](/reference/cross-language-parity/)

## Rendering and tooling

  - [React renderer](/reference/react-renderer/)
  - [Theming](/reference/themes/)
  - [ESLint plugins](/reference/eslint-plugins/)

