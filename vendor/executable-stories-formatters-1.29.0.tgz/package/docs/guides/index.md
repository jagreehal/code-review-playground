---
title: Guides
description: Task-shaped walkthroughs, from writing your first scenario to gating a release on the evidence behind it.
slug: guides
---

Start with [Install](/getting-started/install/) and [your first story](/getting-started/first-story/). Everything below assumes you have a run producing reports.

## Concepts

Read these once and the rest of the docs stop being surprising.

  - [Why not Cucumber?](/guides/why-not-cucumber/)
  - [Four layers, without a world object](/guides/four-layer-model/)
  - [The specification layer](/guides/the-specification-layer/)
  - [Developer experience](/guides/developer-experience/)
  - [Understanding the report](/guides/understanding-the-report/)

## Writing stories

  - [Formatting and metadata](/guides/formatting-and-metadata/)

## Adopting an existing suite

You do not rewrite anything. You annotate the tests you already have.

  - [Setup decision tree](/guides/setup-decision-tree/)
  - [Converting Vitest tests](/guides/converting-vitest/)
  - [Converting Jest tests](/guides/converting-jest/)
  - [Converting Playwright tests](/guides/converting-playwright/)
  - [Converting a CucumberJS suite](/guides/converting-cucumber/)

## Output and reports

  - [Output modes](/guides/output-modes/)
  - [Collating reports](/guides/collating-reports/)
  - [Sharing reports](/guides/sharing-reports/)
  - [CI and source links](/guides/ci-and-source-links/)

## Publishing living documentation

  - [Embed reports in React apps](/guides/embed-in-react-apps/)
  - [Embedding skill and agent HTML](/guides/embedding-skill-html-output/)

## CI gates and review

  - [GitHub Action](/guides/github-action/)
  - [Release confidence](/guides/release-confidence/)
  - [Verify a deploy](/guides/verifying-a-deploy/)
  - [Evidence Review and Code Diff](/guides/evidence-review/)

## Integrations

  - [Publishing to Confluence and Jira](/guides/publishing-to-atlassian/)
  - [TestRail and Xray sync](/guides/test-management-sync/)

## For coding agents

  - [Agent artifact contract](/guides/agent-artifact-contract/)
  - [Agent loops and backpressure](/guides/agent-loops/)

## When something breaks

  - [Common issues](/guides/common-issues/)

