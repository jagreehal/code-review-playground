---
title: 'Executable Stories'
description: Tests that document. Reports that convince. Framework-native story tests for Vitest, Jest, Playwright, Cypress, and Ruby.
template: splash
hero:
  tagline: ""
  actions: []
---

<div class="hero-custom not-content">
  <div class="hero-custom__text">
    <div class="hero-custom__badge">Living docs from the tests you already write</div>
    <h1 class="hero-custom__title">Write it once.<br/>Prove it every run.</h1>
    <p class="hero-custom__subtitle">Your tests already describe how the product behaves. Mark the steps, and the run that proves it also publishes it: for your team, your repo, and your agents.</p>
    <ul class="hero-custom__bullets">
      <li>Keep your runner, assertions, and CI</li>
      <li>No feature files, no step matching</li>
      <li>Adds a reporter and three step markers</li>
    </ul>
    <div class="hero-custom__actions">
      <a href="getting-started/install/" class="hero-btn hero-btn--primary">Get Started</a>
      <a href="guides/agent-artifact-contract/" class="hero-btn hero-btn--ghost">For coding agents</a>
      <a href="https://github.com/jagreehal/executable-stories" class="hero-btn hero-btn--secondary">
        <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor" class="hero-btn__icon"><path d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0016 8c0-4.42-3.58-8-8-8z"/></svg>
        GitHub
      </a>
    </div>
    <div class="hero-custom__stack">
      <div class="hero-custom__stack-row">
        <span class="hero-custom__stack-label">Test frameworks</span>
        <div class="hero-custom__frameworks">
          <a href="getting-started/install/?framework=Vitest" class="hero-custom__fw-tag"><img src="/icons/Vite.js.svg" alt="" class="fw-icon" />Vitest</a>
          <a href="getting-started/install/?framework=Jest" class="hero-custom__fw-tag"><img src="/icons/Jest.svg" alt="" class="fw-icon" />Jest</a>
          <a href="getting-started/install/?framework=Playwright" class="hero-custom__fw-tag"><img src="/icons/Playwright.svg" alt="" class="fw-icon" />Playwright</a>
          <a href="getting-started/install/?framework=Cypress" class="hero-custom__fw-tag"><img src="/icons/Cypress.svg" alt="" class="fw-icon" />Cypress</a>
        </div>
      </div>
      <div class="hero-custom__stack-row">
        <span class="hero-custom__stack-label">Language adapters</span>
        <div class="hero-custom__frameworks">
          <a href="getting-started/install/?framework=Go" class="hero-custom__fw-tag"><img src="/icons/Go.svg" alt="" class="fw-icon" />Go</a>
          <a href="getting-started/install/?framework=Python" class="hero-custom__fw-tag"><img src="/icons/Python.svg" alt="" class="fw-icon" />Python</a>
          <a href="getting-started/install/?framework=Ruby" class="hero-custom__fw-tag"><img src="/icons/Ruby.svg" alt="" class="fw-icon" />Ruby</a>
          <a href="getting-started/install/?framework=Rust" class="hero-custom__fw-tag"><img src="/icons/Rust.svg" alt="" class="fw-icon" />Rust</a>
          <a href="getting-started/install/?framework=Kotlin" class="hero-custom__fw-tag"><img src="/icons/Java.svg" alt="" class="fw-icon" />Kotlin</a>
          <a href="getting-started/install/?framework=C%23" class="hero-custom__fw-tag"><img src="/icons/NET.svg" alt="" class="fw-icon" />C#</a>
        </div>
      </div>
    </div>
  </div>
  <div class="hero-custom__image">
    <figure class="hero-custom__browser">
      <img src="/screenshots/hero-report.png" alt="Executable Stories HTML report showing passed scenarios with Given/When/Then steps, code blocks, and searchable tags" />
      <figcaption>reports/index.html, from one <code>pnpm test</code></figcaption>
    </figure>
  </div>
</div>

<div class="section-break" />

<div class="section-header not-content">
  <h2 class="section-header__title">Write. Run. Share.</h2>
    <p class="section-header__sub">Two of these you already do. The story markers are the only new part.</p>
</div>

<div class="workflow not-content">
  <div class="workflow__row">
    <div class="workflow__meta">
      <span class="workflow__num">1</span>
      <span class="workflow__label">Write stories in your tests</span>
    </div>
    <div class="workflow__content">

```typescript
story.init(task, { ticket: 'PAY-2847' });
story.given('a cart with 3 items');
story.when('the payment is submitted');
story.then('a receipt is generated');
story.table({
  label: 'Receipt breakdown',
  columns: ['Item', 'Qty', 'Total'],
  rows: [['Widget Pro', '2', '178.00']],
});
```

  </div>
  </div>
  <div class="workflow__row">
    <div class="workflow__meta">
      <span class="workflow__num">2</span>
      <span class="workflow__label">Run your tests</span>
    </div>
    <div class="workflow__content">

```bash
vitest run
npx executable-stories format --format html,markdown
```

  </div>
  </div>
  <div class="workflow__row">
    <div class="workflow__meta">
      <span class="workflow__num">3</span>
      <span class="workflow__label">Share the report</span>
    </div>
    <div class="workflow__content">
      <img src="/screenshots/report-output.png" alt="Generated HTML report" class="workflow__img" />
    </div>
  </div>
</div>

<div class="section-break" />

<div class="section-header not-content">
  <h2 class="section-header__title">From terminal noise to team documentation</h2>
  <p class="section-header__sub">Same test run. Completely different audience.</p>
</div>

<div class="section-break" />

<div class="agent-section not-content">
  <div class="agent-section__text">
    <h2 class="agent-section__title">Behavior catalog for coding agents</h2>
    <p class="agent-section__desc">Storybook indexes components. Executable Stories indexes <strong>behavior scenarios with execution truth</strong>: pass, fail, skip, steps, and docs from the last test run.</p>
    <ul class="agent-section__list">
      <li>Stable StoryReport v1 JSON contract</li>
      <li>Scenario index via <code>list --list-format json</code></li>
      <li>Read-only MCP tools (<code>list_scenarios</code>, <code>get_failing_scenarios</code>, …)</li>
      <li>Release gates, deployment drift, and tested-together manifests</li>
    </ul>
    <div class="agent-section__links">
      <a href="guides/agent-artifact-contract/" class="hero-btn hero-btn--primary">Agent artifact contract</a>
      <a href="guides/release-confidence/" class="hero-btn hero-btn--secondary">Release confidence</a>
    </div>
  </div>
</div>

<div class="section-break" />

<div class="section-header not-content">
  <h2 class="section-header__title">Attach the proof to the step it belongs to</h2>
  <p class="section-header__sub">No separate files. No templates. Every doc entry is one line in your test.</p>
</div>

<div class="feature-bento not-content">
  <a href="guides/formatting-and-metadata/" class="feature-tile feature-tile--wide">
    <img src="/screenshots/feature-mermaid.png" alt="Mermaid diagram in report" loading="lazy" decoding="async" class="feature-tile__img" />
    <div class="feature-tile__body">
      <div class="feature-tile__name">Mermaid diagrams</div>
      <div class="feature-tile__desc">Sequence diagrams, flowcharts, and ER diagrams rendered live in the report.</div>
    </div>
  </a>
  <a href="guides/formatting-and-metadata/" class="feature-tile">
    <img src="/screenshots/feature-code.png" alt="Syntax-highlighted code in report" loading="lazy" decoding="async" class="feature-tile__img" />
    <div class="feature-tile__body">
      <div class="feature-tile__name">Code blocks</div>
      <div class="feature-tile__desc">Syntax-highlighted TypeScript, SQL, YAML, or any language.</div>
    </div>
  </a>
  <a href="guides/formatting-and-metadata/" class="feature-tile">
    <img src="/screenshots/feature-tables.png" alt="Table data in report" loading="lazy" decoding="async" class="feature-tile__img" />
    <div class="feature-tile__body">
      <div class="feature-tile__name">Tables and JSON</div>
      <div class="feature-tile__desc">Structured data, key-value pairs, and JSON objects.</div>
    </div>
  </a>
  <a href="guides/formatting-and-metadata/" class="feature-tile feature-tile--wide">
    <img src="/screenshots/feature-tickets.png" alt="A scenario showing why a rule exists, its tags, and a link to the pricing policy" loading="lazy" decoding="async" class="feature-tile__img feature-tile__img--lower" />
    <div class="feature-tile__body">
      <div class="feature-tile__name">Rules and rationale</div>
      <div class="feature-tile__desc">Why a rule exists, with its tags and links, on the scenario itself.</div>
    </div>
  </a>
  <a href="guides/formatting-and-metadata/" class="feature-tile feature-tile--wide">
    <img src="/screenshots/feature-traces.png" alt="OpenTelemetry trace waterfall" loading="lazy" decoding="async" class="feature-tile__img" />
    <div class="feature-tile__body">
      <div class="feature-tile__name">OTel traces</div>
      <div class="feature-tile__desc">Waterfall view of OpenTelemetry spans with durations.</div>
    </div>
  </a>
  <a href="reference/themes/" class="feature-tile">
    <img src="/screenshots/feature-search.png" alt="Report search and filter UI" loading="lazy" decoding="async" class="feature-tile__img" />
    <div class="feature-tile__body">
      <div class="feature-tile__name">Search and filter</div>
      <div class="feature-tile__desc">Full-text search, tag filters, keyboard shortcuts.</div>
    </div>
  </a>
</div>

<div class="section-break" />

<div class="section-header not-content">
  <h2 class="section-header__title">Same tests, different readers</h2>
  <p class="section-header__sub">Teach your AI agent to write documentation for your audience.</p>
</div>

<div class="section-break" />

<div class="diff-section not-content">
  <div class="diff-section__text">
    <h2 class="diff-section__title">Compare runs across sprints</h2>
    <p class="diff-section__desc">Generate diff reports to spot regressions, track fixes, and see what changed between any two test runs.</p>
    <div class="diff-section__features">
      <div class="diff-section__feature">
        <span class="diff-section__tag diff-section__tag--red">Regressed</span>
        <span>Tests that started failing</span>
      </div>
      <div class="diff-section__feature">
        <span class="diff-section__tag diff-section__tag--green">Fixed</span>
        <span>Tests that were repaired</span>
      </div>
      <div class="diff-section__feature">
        <span class="diff-section__tag diff-section__tag--blue">Changed</span>
        <span>Duration or status shifts</span>
      </div>
    </div>
  </div>
  <div class="diff-section__image">
    <img src="/screenshots/diff-report-dark.png" alt="Sprint comparison diff report showing regressions, fixes, and changes" loading="lazy" decoding="async" />
  </div>
</div>

<div class="section-break" />

<div class="section-header not-content">
  <h2 class="section-header__title">Light, dark, and yours</h2>
  <p class="section-header__sub">The report follows the system colour scheme and ships a manual toggle. One <code>--es-*</code> CSS override re-themes the HTML report and the React component at once. <a href="reference/themes/">Theming →</a></p>
</div>

<div class="section-break" />

<div class="section-header not-content">
  <h2 class="section-header__title">Native to your framework</h2>
  <p class="section-header__sub">Same API across frameworks. Same report output. 10 languages supported.</p>
</div>

<div class="stack-section not-content">
  <div class="stack-section__code">

**Vitest**

```typescript
import { story, doc } from 'executable-stories-vitest';

it('user logs in', ({ task }) => {
  const s = story.init(task);
  s.given('a registered user');
  s.when('they submit valid credentials');
  s.then('they see the dashboard');
  s.json({ label: 'Session', value: { role: 'admin' } });
});
```

**Jest**

```typescript
import { story, given, when, then } from 'executable-stories-jest';

it('user logs in', () => {
  story.init();
  given('a registered user');
  when('they submit valid credentials');
  then('they see the dashboard');
  story.json({ label: 'Session', value: { role: 'admin' } });
});
```

**Playwright**

```typescript
import { story, given, when, then } from 'executable-stories-playwright';

test('user logs in', async ({ page }, testInfo) => {
  story.init(testInfo);
  given('a registered user');
  when('they submit valid credentials');
  then('they see the dashboard');
});
```

**Cypress**

```typescript
import { story, given, when, then } from 'executable-stories-cypress';

it('user logs in', () => {
  story.init();
  given('a registered user');
  when('they submit valid credentials');
  then('they see the dashboard');
});
```

  </div>
  <div class="stack-section__formats">
    <h3 class="stack-section__heading">Output formats</h3>
    <div class="format-list">
      <span class="format-tag"><code>.html</code> HTML Report</span>
      <span class="format-tag"><code>.md</code> Markdown</span>
      <span class="format-tag"><code>.release-manifest.md</code> Release Manifest</span>
      <span class="format-tag"><code>.junit.xml</code> JUnit XML</span>
      <span class="format-tag"><code>.cucumber.json</code> Cucumber JSON</span>
      <span class="format-tag"><code>.html</code> Cucumber HTML</span>
      <span class="format-tag"><code>.ndjson</code> Cucumber Messages</span>
    </div>
    <h3 class="stack-section__heading stack-section__heading--langs">Also available</h3>
    <div class="lang-grid">
      <span class="lang-tag"><img src="/icons/Go.svg" alt="" class="lang-icon" />Go</span>
      <span class="lang-tag"><img src="/icons/Python.svg" alt="" class="lang-icon" />Python</span>
      <span class="lang-tag"><img src="/icons/Ruby.svg" alt="" class="lang-icon" />Ruby</span>
      <span class="lang-tag"><img src="/icons/Rust.svg" alt="" class="lang-icon" />Rust</span>
      <span class="lang-tag"><img src="/icons/Java.svg" alt="" class="lang-icon" />Kotlin</span>
      <span class="lang-tag"><img src="/icons/NET.svg" alt="" class="lang-icon" />C#</span>
    </div>
  </div>
</div>

<div class="section-break" />

<div class="cta not-content">
  <h2 class="cta__title">Get started in under a minute</h2>
  <p class="cta__desc">Add the adapter to the framework you already run. Your tests keep working exactly as they did.</p>

**pnpm**

```bash
pnpm add -D executable-stories-vitest executable-stories-formatters
```

**npm**

```bash
npm install -D executable-stories-vitest executable-stories-formatters
```

**yarn**

```bash
yarn add -D executable-stories-vitest executable-stories-formatters
```

**gem**

```bash
gem install executable-stories-ruby
```

  <div class="cta__links">
    <a href="getting-started/first-story/" class="hero-btn hero-btn--primary">Write your first story</a>
    <a href="guides/why-not-cucumber/" class="hero-btn hero-btn--secondary">Why not Cucumber?</a>
  </div>
</div>

