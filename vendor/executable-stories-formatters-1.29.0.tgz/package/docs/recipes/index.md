---
title: Recipes
description: Thirty-two worked scenarios, each with the test code for every supported framework and the report output it produces.
slug: recipes
---

Every recipe shows one scenario twice: the test you write, and the documentation it generates. Pick your framework in the tab strip on any recipe and the rest of the site follows that choice.

> **One output, nine adapters**
The generated documentation is identical whichever adapter you use. Only the test code changes. Eight recipes are marked **all languages** below; the rest cover Vitest, Jest, Playwright, and Cypress.

## Step structure

How Given, When, and Then read when you repeat them. A repeated keyword renders as **And** from the second occurrence onward.

  - [User logs in successfully](/recipes/user-logs-in-successfully/)
  - [User updates profile details](/recipes/user-updates-profile-details/)
  - [Checkout calculates totals](/recipes/checkout-calculates-totals/)
  - [Password reset flow](/recipes/password-reset-flow/)
  - [Logout clears session](/recipes/logout-clears-session/)
  - [Two step checkout](/recipes/two-step-checkout/)

## Contrast and explicit keywords

`story.and()` and `story.but()` never auto-convert, so use them when the wording matters more than the keyword arithmetic.

  - [Login blocked for suspended user](/recipes/login-blocked-suspended-user/)
  - [Payment declined](/recipes/payment-declined/)
  - [Guest checkout allowed](/recipes/guest-checkout-allowed/)
  - [Search results show highlights](/recipes/search-results-show-highlights/)
  - [Report shows fields in order](/recipes/report-shows-fields-in-order/)
  - [Document status changes](/recipes/document-status-changes/)

## Attaching data to a step

Tables, JSON, and code blocks travel with the step they belong to, so a reader sees the payload rather than a description of it.

  - [Bulk user creation](/recipes/bulk-user-creation/)
  - [Calculate shipping options](/recipes/calculate-shipping-options/)
  - [Configure feature flags](/recipes/configure-feature-flags/)
  - [Update preferences](/recipes/update-preferences/)
  - [API accepts a JSON payload](/recipes/api-accepts-json-payload/)
  - [Import XML invoice](/recipes/import-xml-invoice/)
  - [Render markdown](/recipes/render-markdown/)
  - [Import users and send welcome email](/recipes/import-users-welcome-email/)

## Scenario outlines

Loop over your cases and register one scenario per row. No Examples table, no placeholder syntax, just the language you already write.

  - [Login errors](/recipes/login-errors/)
  - [Many login attempts](/recipes/many-login-attempts/)
  - [Shipping eligibility](/recipes/shipping-eligibility/)
  - [Tax calculation by region](/recipes/tax-calculation-by-region/)
  - [Create users from table input](/recipes/create-users-from-table/)
  - [Post JSON payload](/recipes/post-json-payload/)

## Shared setup and business rules

  - [Change email address](/recipes/change-email-address/)
  - [Change password](/recipes/change-password/)
  - [Eligible customer gets discount](/recipes/eligible-customer-gets-discount/)
  - [Ineligible customer does not get discount](/recipes/ineligible-customer-no-discount/)
  - [Create order](/recipes/create-order/)
  - [Login works](/recipes/login-works/)

## Where this code lives

Each snippet is lifted from a suite that runs in CI, so none of it drifts:

| Adapter | Source |
| --- | --- |
| Vitest | [`apps/vitest-example/src/replicate.story.test.ts`](https://github.com/jagreehal/executable-stories/tree/main/apps/vitest-example) |
| Jest | [`apps/jest-example`](https://github.com/jagreehal/executable-stories/tree/main/apps/jest-example) |
| Playwright | [`apps/playwright-example`](https://github.com/jagreehal/executable-stories/tree/main/apps/playwright-example) |
| Cypress | [`apps/cypress-example`](https://github.com/jagreehal/executable-stories/tree/main/apps/cypress-example) |
| Go, Python, Rust, Kotlin, C# | [`packages/executable-stories-*`](https://github.com/jagreehal/executable-stories/tree/main/packages) |

For the full API behind these recipes, see the [story and doc API reference](/reference/vitest-story-api/).
