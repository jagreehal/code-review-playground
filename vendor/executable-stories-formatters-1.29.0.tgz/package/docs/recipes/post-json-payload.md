---
title: Post JSON payload
description: Scenario outline with doc.json
---

An outline where every case carries its own JSON payload.

## The test

**Vitest**

```typescript
import { story } from 'executable-stories-vitest';
import { it } from 'vitest';

const postPayloadExamples = [
  { id: "123", status: "active", code: "200" },
  { id: "456", status: "invalid", code: "400" },
];
for (const row of postPayloadExamples) {
  it(`Post JSON payload: ${row.id} -> ${row.code}`, ({ task }) => {
    story.init(task);
    story.given("the payload is");
    story.json({ label: "Payload", value: { id: row.id, status: row.status } });
    story.when("the client posts the payload");
    story.then(`the response status should be ${row.code}`);
  });
}
```

**Jest**

```typescript
import { story } from 'executable-stories-jest';

const postPayloadExamples = [
  { id: "123", status: "active", code: "200" },
  { id: "456", status: "invalid", code: "400" },
];
for (const row of postPayloadExamples) {
  it(`Post JSON payload: ${row.id} -> ${row.code}`, () => {
    story.init();
    story.given("the payload is");
    story.json({ label: "Payload", value: { id: row.id, status: row.status } });
    story.when("the client posts the payload");
    story.then(`the response status should be ${row.code}`);
  });
}
```

**Playwright**

```typescript
import { test } from '@playwright/test';
import { story } from 'executable-stories-playwright';

const postPayloadExamples = [
  { id: "123", status: "active", code: "200" },
  { id: "456", status: "invalid", code: "400" },
];
for (const row of postPayloadExamples) {
  test(`Post JSON payload: ${row.id} -> ${row.code}`, async ({}, testInfo) => {
    story.init(testInfo);
    story.given("the payload is");
    story.json({ label: "Payload", value: { id: row.id, status: row.status } });
    story.when("the client posts the payload");
    story.then(`the response status should be ${row.code}`);
  });
}
```

**Cypress**

```typescript
import { story } from 'executable-stories-cypress';

const postPayloadExamples = [
  { id: "123", status: "active", code: "200" },
  { id: "456", status: "invalid", code: "400" },
];
for (const row of postPayloadExamples) {
  it(`Post JSON payload: ${row.id} -> ${row.code}`, () => {
    story.init();
    story.given("the payload is");
    story.json({ label: "Payload", value: { id: row.id, status: row.status } });
    story.when("the client posts the payload");
    story.then(`the response status should be ${row.code}`);
  });
}
```

## What the report renders

```markdown
### ✅ Post JSON payload: 123 -> 200

- **Given** the payload is
    **Payload**
    ```json
    { "id": "123", "status": "active" }
    ```
- **When** the client posts the payload
- **Then** the response status should be 200
```
