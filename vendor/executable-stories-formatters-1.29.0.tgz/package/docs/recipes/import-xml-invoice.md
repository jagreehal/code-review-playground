---
title: Import XML invoice
description: DocString (XML) with doc.code
---

Attach an XML document to a step with `story.code()`.

## The test

**Vitest**

```typescript
import { story } from 'executable-stories-vitest';
import { it } from 'vitest';

it("Import XML invoice", ({ task }) => {
  story.init(task);
  story.given("the invoice XML is");
  story.code({
    label: "Invoice",
    content: `<invoice>
  <id>INV-100</id>
  <amount>42.50</amount>
  <currency>USD</currency>
</invoice>`,
    lang: "xml",
  });
  story.when("the user imports the invoice");
  story.then("the invoice should be saved");
  story.then("the invoice total should be 42.50 USD");
});
```

**Jest**

```typescript
import { story } from 'executable-stories-jest';

it("Import XML invoice", () => {
  story.init();
  story.given("the invoice XML is");
  story.code({
    label: "Invoice",
    content: `<invoice>
  <id>INV-100</id>
  <amount>42.50</amount>
  <currency>USD</currency>
</invoice>`,
    lang: "xml",
  });
  story.when("the user imports the invoice");
  story.then("the invoice should be saved");
  story.then("the invoice total should be 42.50 USD");
});
```

**Playwright**

```typescript
import { test } from '@playwright/test';
import { story } from 'executable-stories-playwright';

test("Import XML invoice", async ({}, testInfo) => {
  story.init(testInfo);
  story.given("the invoice XML is");
  story.code({
    label: "Invoice",
    content: `<invoice>
  <id>INV-100</id>
  <amount>42.50</amount>
  <currency>USD</currency>
</invoice>`,
    lang: "xml",
  });
  story.when("the user imports the invoice");
  story.then("the invoice should be saved");
  story.then("the invoice total should be 42.50 USD");
});
```

**Cypress**

```typescript
import { story } from 'executable-stories-cypress';

it("Import XML invoice", () => {
  story.init();
  story.given("the invoice XML is");
  story.code({
    label: "Invoice",
    content: `<invoice>
  <id>INV-100</id>
  <amount>42.50</amount>
  <currency>USD</currency>
</invoice>`,
    lang: "xml",
  });
  story.when("the user imports the invoice");
  story.then("the invoice should be saved");
  story.then("the invoice total should be 42.50 USD");
});
```

**Go**

```go
import (
    "testing"
    es "github.com/jagreehal/executable-stories/packages/executable-stories-go"
)

func TestImportXMLInvoice(t *testing.T) {
    s := es.Init(t, "Import XML invoice")
    s.Given("the invoice XML is")
    s.Code("Invoice", `<invoice>
  <id>INV-100</id>
  <amount>42.50</amount>
  <currency>USD</currency>
</invoice>`, "xml")
    s.When("the user imports the invoice")
    s.Then("the invoice should be saved")
    s.Then("the invoice total should be 42.50 USD")
}
```

**Python**

```python
from executable_stories import story

def test_import_xml_invoice():
    story.init("Import XML invoice")
    story.given("the invoice XML is")
    story.code("Invoice", """<invoice>
  <id>INV-100</id>
  <amount>42.50</amount>
  <currency>USD</currency>
</invoice>""", lang="xml")
    story.when("the user imports the invoice")
    story.then("the invoice should be saved")
    story.then("the invoice total should be 42.50 USD")
```

**Rust**

```rust
use executable_stories::Story;

#[test]
fn test_import_xml_invoice() {
    let mut s = Story::new("Import XML invoice");
    s.given("the invoice XML is");
    s.code("Invoice", "<invoice>\n  <id>INV-100</id>\n  <amount>42.50</amount>\n  <currency>USD</currency>\n</invoice>", Some("xml"));
    s.when("the user imports the invoice");
    s.then("the invoice should be saved");
    s.then("the invoice total should be 42.50 USD");
}
```

**Kotlin**

```kotlin
import dev.executablestories.junit5.Story
import org.junit.jupiter.api.Test

class InvoiceTest {
    @Test
    fun `import xml invoice`() {
        Story.init("Import XML invoice")
        Story.given("the invoice XML is")
        Story.code("Invoice", """
            <invoice>
              <id>INV-100</id>
              <amount>42.50</amount>
              <currency>USD</currency>
            </invoice>
        """.trimIndent(), "xml")
        Story.`when`("the user imports the invoice")
        Story.then("the invoice should be saved")
        Story.then("the invoice total should be 42.50 USD")
    }
}
```

**C#**

```csharp
using ExecutableStories.Xunit;
using Xunit;

public class InvoiceTests : IDisposable
{
    [Fact]
    public void ImportXmlInvoice()
    {
        Story.Init("Import XML invoice");
        Story.Given("the invoice XML is");
        Story.Code("Invoice", @"<invoice>
  <id>INV-100</id>
  <amount>42.50</amount>
  <currency>USD</currency>
</invoice>", "xml");
        Story.When("the user imports the invoice");
        Story.Then("the invoice should be saved");
        Story.Then("the invoice total should be 42.50 USD");
    }
}
```

## What the report renders

```markdown
### ✅ Import XML invoice

- **Given** the invoice XML is
    **Invoice**
    ```xml
    <invoice>
      <id>INV-100</id>
      <amount>42.50</amount>
      <currency>USD</currency>
    </invoice>
    ```
- **When** the user imports the invoice
- **Then** the invoice should be saved
- **And** the invoice total should be 42.50 USD
```
