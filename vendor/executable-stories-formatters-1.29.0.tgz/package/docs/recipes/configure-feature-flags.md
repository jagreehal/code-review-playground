---
title: Configure feature flags
description: Complex DataTable
---

A wide table carrying more columns than a step description could hold.

## The test

**Vitest**

```typescript
import { story } from 'executable-stories-vitest';
import { it } from 'vitest';

it("Configure feature flags", ({ task }) => {
  story.init(task);
  story.given("the following feature flags are set");
  story.table({
    label: "Feature flags",
    columns: ["service", "flag", "enabled"],
    rows: [
      ["web", "new_checkout_ui", "true"],
      ["api", "strict_rate_limiting", "false"],
    ],
  });
  story.when("the system starts");
  story.then('the flag "new_checkout_ui" should be enabled for "web"');
  story.then('the flag "strict_rate_limiting" should be disabled for "api"');
});
```

**Jest**

```typescript
import { story } from 'executable-stories-jest';

it("Configure feature flags", () => {
  story.init();
  story.given("the following feature flags are set");
  story.table({
    label: "Feature flags",
    columns: ["service", "flag", "enabled"],
    rows: [
      ["web", "new_checkout_ui", "true"],
      ["api", "strict_rate_limiting", "false"],
    ],
  });
  story.when("the system starts");
  story.then('the flag "new_checkout_ui" should be enabled for "web"');
  story.then('the flag "strict_rate_limiting" should be disabled for "api"');
});
```

**Playwright**

```typescript
import { test } from '@playwright/test';
import { story } from 'executable-stories-playwright';

test("Configure feature flags", async ({}, testInfo) => {
  story.init(testInfo);
  story.given("the following feature flags are set");
  story.table({
    label: "Feature flags",
    columns: ["service", "flag", "enabled"],
    rows: [
      ["web", "new_checkout_ui", "true"],
      ["api", "strict_rate_limiting", "false"],
    ],
  });
  story.when("the system starts");
  story.then('the flag "new_checkout_ui" should be enabled for "web"');
  story.then('the flag "strict_rate_limiting" should be disabled for "api"');
});
```

**Cypress**

```typescript
import { story } from 'executable-stories-cypress';

it("Configure feature flags", () => {
  story.init();
  story.given("the following feature flags are set");
  story.table({
    label: "Feature flags",
    columns: ["service", "flag", "enabled"],
    rows: [
      ["web", "new_checkout_ui", "true"],
      ["api", "strict_rate_limiting", "false"],
    ],
  });
  story.when("the system starts");
  story.then('the flag "new_checkout_ui" should be enabled for "web"');
  story.then('the flag "strict_rate_limiting" should be disabled for "api"');
});
```

## What the report renders

```markdown
### ✅ Configure feature flags

- **Given** the following feature flags are set
    **Feature flags**
    | service | flag | enabled |
    | --- | --- | --- |
    | web | new_checkout_ui | true |
    | api | strict_rate_limiting | false |
- **When** the system starts
- **Then** the flag "new_checkout_ui" should be enabled for "web"
- **And** the flag "strict_rate_limiting" should be disabled for "api"
```
