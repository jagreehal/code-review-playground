---
title: Create users from table input
description: Scenario outline with doc.table
---

Loop over table rows and register one scenario per row.

## The test

**Vitest**

```typescript
import { story } from 'executable-stories-vitest';
import { it } from 'vitest';

const createUserExamples = [
  { email: "a@example.com", role: "user" },
  { email: "admin@example.com", role: "admin" },
];
for (const row of createUserExamples) {
  it(`Create users from table input: ${row.email}`, ({ task }) => {
    story.init(task);
    story.given("the admin is on the create user page");
    story.when("the admin submits the following user details");
    story.table({
      label: "Details",
      columns: ["email", "role"],
      rows: [[row.email, row.role]],
    });
    story.then(`the user "${row.email}" should exist with role "${row.role}"`);
  });
}
```

**Jest**

```typescript
import { story } from 'executable-stories-jest';

const createUserExamples = [
  { email: "a@example.com", role: "user" },
  { email: "admin@example.com", role: "admin" },
];
for (const row of createUserExamples) {
  it(`Create users from table input: ${row.email}`, () => {
    story.init();
    story.given("the admin is on the create user page");
    story.when("the admin submits the following user details");
    story.table({
      label: "Details",
      columns: ["email", "role"],
      rows: [[row.email, row.role]],
    });
    story.then(`the user "${row.email}" should exist with role "${row.role}"`);
  });
}
```

**Playwright**

```typescript
import { test } from '@playwright/test';
import { story } from 'executable-stories-playwright';

const createUserExamples = [
  { email: "a@example.com", role: "user" },
  { email: "admin@example.com", role: "admin" },
];
for (const row of createUserExamples) {
  test(`Create users from table input: ${row.email}`, async ({}, testInfo) => {
    story.init(testInfo);
    story.given("the admin is on the create user page");
    story.when("the admin submits the following user details");
    story.table({
      label: "Details",
      columns: ["email", "role"],
      rows: [[row.email, row.role]],
    });
    story.then(`the user "${row.email}" should exist with role "${row.role}"`);
  });
}
```

**Cypress**

```typescript
import { story } from 'executable-stories-cypress';

const createUserExamples = [
  { email: "a@example.com", role: "user" },
  { email: "admin@example.com", role: "admin" },
];
for (const row of createUserExamples) {
  it(`Create users from table input: ${row.email}`, () => {
    story.init();
    story.given("the admin is on the create user page");
    story.when("the admin submits the following user details");
    story.table({
      label: "Details",
      columns: ["email", "role"],
      rows: [[row.email, row.role]],
    });
    story.then(`the user "${row.email}" should exist with role "${row.role}"`);
  });
}
```

## What the report renders

```markdown
### ✅ Create users from table input: a@example.com

- **Given** the admin is on the create user page
- **When** the admin submits the following user details
    **Details**
    | email | role |
    | --- | --- |
    | a@example.com | user |
- **Then** the user "a@example.com" should exist with role "user"
```
