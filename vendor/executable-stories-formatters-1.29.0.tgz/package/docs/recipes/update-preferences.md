---
title: Update preferences
description: DataTable as key-value pairs
---

A two-column table read as key and value.

## The test

**Vitest**

```typescript
import { story } from 'executable-stories-vitest';
import { it } from 'vitest';

it("Update preferences", ({ task }) => {
  story.init(task);
  story.given("the user has the following preferences");
  story.table({
    label: "Preferences",
    columns: ["key", "value"],
    rows: [
      ["email_opt_in", "true"],
      ["theme", "dark"],
      ["timezone", "UTC"],
    ],
  });
  story.when("the user saves preferences");
  story.then("the preferences should be persisted");
});
```

**Jest**

```typescript
import { story } from 'executable-stories-jest';

it("Update preferences", () => {
  story.init();
  story.given("the user has the following preferences");
  story.table({
    label: "Preferences",
    columns: ["key", "value"],
    rows: [
      ["email_opt_in", "true"],
      ["theme", "dark"],
      ["timezone", "UTC"],
    ],
  });
  story.when("the user saves preferences");
  story.then("the preferences should be persisted");
});
```

**Playwright**

```typescript
import { test } from '@playwright/test';
import { story } from 'executable-stories-playwright';

test("Update preferences", async ({}, testInfo) => {
  story.init(testInfo);
  story.given("the user has the following preferences");
  story.table({
    label: "Preferences",
    columns: ["key", "value"],
    rows: [
      ["email_opt_in", "true"],
      ["theme", "dark"],
      ["timezone", "UTC"],
    ],
  });
  story.when("the user saves preferences");
  story.then("the preferences should be persisted");
});
```

**Cypress**

```typescript
import { story } from 'executable-stories-cypress';

it("Update preferences", () => {
  story.init();
  story.given("the user has the following preferences");
  story.table({
    label: "Preferences",
    columns: ["key", "value"],
    rows: [
      ["email_opt_in", "true"],
      ["theme", "dark"],
      ["timezone", "UTC"],
    ],
  });
  story.when("the user saves preferences");
  story.then("the preferences should be persisted");
});
```

## What the report renders

```markdown
### ✅ Update preferences

- **Given** the user has the following preferences
    **Preferences**
    | key | value |
    | --- | --- |
    | email_opt_in | true |
    | theme | dark |
    | timezone | UTC |
- **When** the user saves preferences
- **Then** the preferences should be persisted
```
