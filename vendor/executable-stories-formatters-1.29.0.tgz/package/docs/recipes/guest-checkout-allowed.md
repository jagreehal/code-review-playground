---
title: Guest checkout allowed
description: doc.note for But in Given
---

Use `story.note()` to explain why a step is worded as a negative.

## The test

**Vitest**

```typescript
import { story } from 'executable-stories-vitest';
import { it } from 'vitest';

it("Guest checkout allowed", ({ task }) => {
  story.init(task);
  story.given("the user is on the checkout page");
  story.given("the user is not logged in");
  story.note("But guest checkout is enabled");
  story.when("the user submits an order as a guest");
  story.then("the order should be created");
});
```

**Jest**

```typescript
import { story } from 'executable-stories-jest';

it("Guest checkout allowed", () => {
  story.init();
  story.given("the user is on the checkout page");
  story.given("the user is not logged in");
  story.note("But guest checkout is enabled");
  story.when("the user submits an order as a guest");
  story.then("the order should be created");
});
```

**Playwright**

```typescript
import { test } from '@playwright/test';
import { story } from 'executable-stories-playwright';

test("Guest checkout allowed", async ({}, testInfo) => {
  story.init(testInfo);
  story.given("the user is on the checkout page");
  story.given("the user is not logged in");
  story.note("But guest checkout is enabled");
  story.when("the user submits an order as a guest");
  story.then("the order should be created");
});
```

**Cypress**

```typescript
import { story } from 'executable-stories-cypress';

it("Guest checkout allowed", () => {
  story.init();
  story.given("the user is on the checkout page");
  story.given("the user is not logged in");
  story.note("But guest checkout is enabled");
  story.when("the user submits an order as a guest");
  story.then("the order should be created");
});
```

## What the report renders

```markdown
### ✅ Guest checkout allowed

- **Given** the user is on the checkout page
- **And** the user is not logged in
    _Note:_ But guest checkout is enabled
- **When** the user submits an order as a guest
- **Then** the order should be created
```
