---
title: Ineligible customer does not get discount
description: Rule block, negative path
---

The negative path of the same rule. Pair it with the positive path so the rule is documented from both sides.

## The test

**Vitest**

```typescript
import { story } from 'executable-stories-vitest';
import { it } from 'vitest';

it("Ineligible customer does not get discount", ({ task }) => {
  story.init(task);
  story.given("the customer is not eligible for discounts");
  story.when("the customer checks out");
  story.then("no discount should be applied");
});
```

**Jest**

```typescript
import { story } from 'executable-stories-jest';

it("Ineligible customer does not get discount", () => {
  story.init();
  story.given("the customer is not eligible for discounts");
  story.when("the customer checks out");
  story.then("no discount should be applied");
});
```

**Playwright**

```typescript
import { test } from '@playwright/test';
import { story } from 'executable-stories-playwright';

test("Ineligible customer does not get discount", async ({}, testInfo) => {
  story.init(testInfo);
  story.given("the customer is not eligible for discounts");
  story.when("the customer checks out");
  story.then("no discount should be applied");
});
```

**Cypress**

```typescript
import { story } from 'executable-stories-cypress';

it("Ineligible customer does not get discount", () => {
  story.init();
  story.given("the customer is not eligible for discounts");
  story.when("the customer checks out");
  story.then("no discount should be applied");
});
```

## What the report renders

```markdown
### ✅ Ineligible customer does not get discount

- **Given** the customer is not eligible for discounts
- **When** the customer checks out
- **Then** no discount should be applied
```
