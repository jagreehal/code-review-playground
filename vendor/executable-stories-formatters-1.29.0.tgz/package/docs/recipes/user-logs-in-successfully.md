---
title: User logs in successfully
description: Multiple Given, single When, single Then
---

Three Given steps in a row. The first renders as Given, the rest as And.

## The test

**Vitest**

```typescript
import { story } from 'executable-stories-vitest';
import { describe, it } from 'vitest';

describe('Login', () => {
  it('User logs in successfully', ({ task }) => {
    story.init(task);
    story.given('the user account exists');
    story.given('the user is on the login page');
    story.given('the account is active');
    story.when('the user submits valid credentials');
    story.then('the user should see the dashboard');
  });
});
```

**Jest**

```typescript
import { story } from 'executable-stories-jest';

describe('Login', () => {
  it('User logs in successfully', () => {
    story.init();
    story.given('the user account exists');
    story.given('the user is on the login page');
    story.given('the account is active');
    story.when('the user submits valid credentials');
    story.then('the user should see the dashboard');
  });
});
```

**Playwright**

```typescript
import { test } from '@playwright/test';
import { story } from 'executable-stories-playwright';

test.describe('Login', () => {
  test('User logs in successfully', async ({}, testInfo) => {
    story.init(testInfo);
    story.given('the user account exists');
    story.given('the user is on the login page');
    story.given('the account is active');
    story.when('the user submits valid credentials');
    story.then('the user should see the dashboard');
  });
});
```

**Cypress**

```typescript
import { story } from 'executable-stories-cypress';

describe('Login', () => {
  it('User logs in successfully', () => {
    story.init();
    story.given('the user account exists');
    story.given('the user is on the login page');
    story.given('the account is active');
    story.when('the user submits valid credentials');
    story.then('the user should see the dashboard');
  });
});
```

**Go**

```go
import (
    "testing"
    es "github.com/jagreehal/executable-stories/packages/executable-stories-go"
)

func TestUserLogsInSuccessfully(t *testing.T) {
    s := es.Init(t, "User logs in successfully")
    s.Given("the user account exists")
    s.Given("the user is on the login page")
    s.Given("the account is active")
    s.When("the user submits valid credentials")
    s.Then("the user should see the dashboard")
}
```

**Python**

```python
from executable_stories import story

def test_user_logs_in_successfully():
    story.init("User logs in successfully")
    story.given("the user account exists")
    story.given("the user is on the login page")
    story.given("the account is active")
    story.when("the user submits valid credentials")
    story.then("the user should see the dashboard")
```

**Rust**

```rust
use executable_stories::Story;

#[test]
fn test_user_logs_in_successfully() {
    let mut s = Story::new("User logs in successfully");
    s.given("the user account exists");
    s.given("the user is on the login page");
    s.given("the account is active");
    s.when("the user submits valid credentials");
    s.then("the user should see the dashboard");
}
```

**Kotlin**

```kotlin
import dev.executablestories.junit5.Story
import org.junit.jupiter.api.Test

class LoginTest {
    @Test
    fun `user logs in successfully`() {
        Story.init("User logs in successfully")
        Story.given("the user account exists")
        Story.given("the user is on the login page")
        Story.given("the account is active")
        Story.`when`("the user submits valid credentials")
        Story.then("the user should see the dashboard")
    }
}
```

**C#**

```csharp
using ExecutableStories.Xunit;
using Xunit;

public class LoginTests : IDisposable
{
    [Fact]
    public void UserLogsInSuccessfully()
    {
        Story.Init("User logs in successfully");
        Story.Given("the user account exists");
        Story.Given("the user is on the login page");
        Story.Given("the account is active");
        Story.When("the user submits valid credentials");
        Story.Then("the user should see the dashboard");
    }
}
```

## What the report renders

```markdown
### ✅ User logs in successfully

- **Given** the user account exists
- **And** the user is on the login page
- **And** the account is active
- **When** the user submits valid credentials
- **Then** the user should see the dashboard
```
