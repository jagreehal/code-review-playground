---
title: Shipping eligibility
description: Scenario outline by country
---

One scenario per country, from a single table.

## The test

**Vitest**

```typescript
import { story } from 'executable-stories-vitest';
import { it } from 'vitest';

const shippingEligibilityExamples = [
  { total: "10", country: "US", eligible: "yes" },
  { total: "10", country: "CA", eligible: "yes" },
  { total: "10", country: "CU", eligible: "no" },
];
for (const row of shippingEligibilityExamples) {
  it(`Shipping eligibility: ${row.country} -> ${row.eligible}`, ({ task }) => {
    story.init(task);
    story.given(`the cart total is ${row.total}`);
    story.given(`the destination country is "${row.country}"`);
    story.when("shipping eligibility is checked");
    story.then(`shipping should be "${row.eligible}"`);
  });
}
```

**Jest**

```typescript
import { story } from 'executable-stories-jest';

const shippingEligibilityExamples = [
  { total: "10", country: "US", eligible: "yes" },
  { total: "10", country: "CA", eligible: "yes" },
  { total: "10", country: "CU", eligible: "no" },
];
for (const row of shippingEligibilityExamples) {
  it(`Shipping eligibility: ${row.country} -> ${row.eligible}`, () => {
    story.init();
    story.given(`the cart total is ${row.total}`);
    story.given(`the destination country is "${row.country}"`);
    story.when("shipping eligibility is checked");
    story.then(`shipping should be "${row.eligible}"`);
  });
}
```

**Playwright**

```typescript
import { test } from '@playwright/test';
import { story } from 'executable-stories-playwright';

const shippingEligibilityExamples = [
  { total: "10", country: "US", eligible: "yes" },
  { total: "10", country: "CA", eligible: "yes" },
  { total: "10", country: "CU", eligible: "no" },
];
for (const row of shippingEligibilityExamples) {
  test(`Shipping eligibility: ${row.country} -> ${row.eligible}`, async ({}, testInfo) => {
    story.init(testInfo);
    story.given(`the cart total is ${row.total}`);
    story.given(`the destination country is "${row.country}"`);
    story.when("shipping eligibility is checked");
    story.then(`shipping should be "${row.eligible}"`);
  });
}
```

**Cypress**

```typescript
import { story } from 'executable-stories-cypress';

const shippingEligibilityExamples = [
  { total: "10", country: "US", eligible: "yes" },
  { total: "10", country: "CA", eligible: "yes" },
  { total: "10", country: "CU", eligible: "no" },
];
for (const row of shippingEligibilityExamples) {
  it(`Shipping eligibility: ${row.country} -> ${row.eligible}`, () => {
    story.init();
    story.given(`the cart total is ${row.total}`);
    story.given(`the destination country is "${row.country}"`);
    story.when("shipping eligibility is checked");
    story.then(`shipping should be "${row.eligible}"`);
  });
}
```

## What the report renders

```markdown
### ✅ Shipping eligibility: US -> yes

- **Given** the cart total is 10
- **And** the destination country is "US"
- **When** shipping eligibility is checked
- **Then** shipping should be "yes"
```
