---
title: Password reset flow
description: Multiple Given, multiple When, multiple Then
---

A longer flow with several steps of each keyword.

## The test

**Vitest**

```typescript
import { story } from 'executable-stories-vitest';
import { it } from 'vitest';

it("Password reset flow", ({ task }) => {
  story.init(task);
  story.given("the user account exists");
  story.given("the user has a verified email");
  story.when("the user requests a password reset");
  story.when("the user opens the reset email link");
  story.when("the user sets a new password");
  story.then("the user should be able to log in with the new password");
  story.then("the old password should no longer work");
});
```

**Jest**

```typescript
import { story } from 'executable-stories-jest';

it("Password reset flow", () => {
  story.init();
  story.given("the user account exists");
  story.given("the user has a verified email");
  story.when("the user requests a password reset");
  story.when("the user opens the reset email link");
  story.when("the user sets a new password");
  story.then("the user should be able to log in with the new password");
  story.then("the old password should no longer work");
});
```

**Playwright**

```typescript
import { test } from '@playwright/test';
import { story } from 'executable-stories-playwright';

test("Password reset flow", async ({}, testInfo) => {
  story.init(testInfo);
  story.given("the user account exists");
  story.given("the user has a verified email");
  story.when("the user requests a password reset");
  story.when("the user opens the reset email link");
  story.when("the user sets a new password");
  story.then("the user should be able to log in with the new password");
  story.then("the old password should no longer work");
});
```

**Cypress**

```typescript
import { story } from 'executable-stories-cypress';

it("Password reset flow", () => {
  story.init();
  story.given("the user account exists");
  story.given("the user has a verified email");
  story.when("the user requests a password reset");
  story.when("the user opens the reset email link");
  story.when("the user sets a new password");
  story.then("the user should be able to log in with the new password");
  story.then("the old password should no longer work");
});
```

## What the report renders

```markdown
### ✅ Password reset flow

- **Given** the user account exists
- **And** the user has a verified email
- **When** the user requests a password reset
- **And** the user opens the reset email link
- **And** the user sets a new password
- **Then** the user should be able to log in with the new password
- **And** the old password should no longer work
```
