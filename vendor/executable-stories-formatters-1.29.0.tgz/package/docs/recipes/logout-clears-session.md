---
title: Logout clears session
description: Repeated Then steps
---

Three Then steps in a row. The first renders as Then, the rest as And.

## The test

**Vitest**

```typescript
import { story } from 'executable-stories-vitest';
import { it } from 'vitest';

it("Logout clears session", ({ task }) => {
  story.init(task);
  story.given("the user is logged in");
  story.when("the user logs out");
  story.then("the session cookie should be cleared");
  story.then("the auth token should be revoked");
  story.then("the user should be redirected to the login page");
});
```

**Jest**

```typescript
import { story } from 'executable-stories-jest';

it("Logout clears session", () => {
  story.init();
  story.given("the user is logged in");
  story.when("the user logs out");
  story.then("the session cookie should be cleared");
  story.then("the auth token should be revoked");
  story.then("the user should be redirected to the login page");
});
```

**Playwright**

```typescript
import { test } from '@playwright/test';
import { story } from 'executable-stories-playwright';

test("Logout clears session", async ({}, testInfo) => {
  story.init(testInfo);
  story.given("the user is logged in");
  story.when("the user logs out");
  story.then("the session cookie should be cleared");
  story.then("the auth token should be revoked");
  story.then("the user should be redirected to the login page");
});
```

**Cypress**

```typescript
import { story } from 'executable-stories-cypress';

it("Logout clears session", () => {
  story.init();
  story.given("the user is logged in");
  story.when("the user logs out");
  story.then("the session cookie should be cleared");
  story.then("the auth token should be revoked");
  story.then("the user should be redirected to the login page");
});
```

## What the report renders

```markdown
### ✅ Logout clears session

- **Given** the user is logged in
- **When** the user logs out
- **Then** the session cookie should be cleared
- **And** the auth token should be revoked
- **And** the user should be redirected to the login page
```
