---
title: Change password
description: Shared background, different When/Then
---

The same background as the previous recipe, with a different When and Then.

## The test

**Vitest**

```typescript
import { story } from 'executable-stories-vitest';
import { it } from 'vitest';

it("Change password", ({ task }) => {
  story.init(task);
  story.given("the user account exists");
  story.given("the user is logged in");
  story.when("the user changes their password");
  story.then("the user should be able to log in with the new password");
});
```

**Jest**

```typescript
import { story } from 'executable-stories-jest';

it("Change password", () => {
  story.init();
  story.given("the user account exists");
  story.given("the user is logged in");
  story.when("the user changes their password");
  story.then("the user should be able to log in with the new password");
});
```

**Playwright**

```typescript
import { test } from '@playwright/test';
import { story } from 'executable-stories-playwright';

test("Change password", async ({}, testInfo) => {
  story.init(testInfo);
  story.given("the user account exists");
  story.given("the user is logged in");
  story.when("the user changes their password");
  story.then("the user should be able to log in with the new password");
});
```

**Cypress**

```typescript
import { story } from 'executable-stories-cypress';

it("Change password", () => {
  story.init();
  story.given("the user account exists");
  story.given("the user is logged in");
  story.when("the user changes their password");
  story.then("the user should be able to log in with the new password");
});
```

## What the report renders

```markdown
### ✅ Change password

- **Given** the user account exists
- **And** the user is logged in
- **When** the user changes their password
- **Then** the user should be able to log in with the new password
```
