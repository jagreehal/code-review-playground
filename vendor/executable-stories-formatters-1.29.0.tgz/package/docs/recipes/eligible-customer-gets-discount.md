---
title: Eligible customer gets discount
description: Rule block, positive path
---

The positive path of a business rule, with the rule named in the scenario title.

## The test

**Vitest**

```typescript
import { story } from 'executable-stories-vitest';
import { describe, it } from 'vitest';

describe("Feature: Discounts", () => {
  describe("Rule: Discounts apply only to eligible customers", () => {
    it("Eligible customer gets discount", ({ task }) => {
      story.init(task);
      story.given("the customer is eligible for discounts");
      story.when("the customer checks out");
      story.then("a discount should be applied");
    });
  });
});
```

**Jest**

```typescript
import { story } from 'executable-stories-jest';

describe("Feature: Discounts", () => {
  describe("Rule: Discounts apply only to eligible customers", () => {
    it("Eligible customer gets discount", () => {
      story.init();
      story.given("the customer is eligible for discounts");
      story.when("the customer checks out");
      story.then("a discount should be applied");
    });
  });
});
```

**Playwright**

```typescript
import { test } from '@playwright/test';
import { story } from 'executable-stories-playwright';

test.describe("Feature: Discounts", () => {
  test.describe("Rule: Discounts apply only to eligible customers", () => {
    test("Eligible customer gets discount", async ({}, testInfo) => {
      story.init(testInfo);
      story.given("the customer is eligible for discounts");
      story.when("the customer checks out");
      story.then("a discount should be applied");
    });
  });
});
```

**Cypress**

```typescript
import { story } from 'executable-stories-cypress';

describe("Feature: Discounts", () => {
  describe("Rule: Discounts apply only to eligible customers", () => {
    it("Eligible customer gets discount", () => {
      story.init();
      story.given("the customer is eligible for discounts");
      story.when("the customer checks out");
      story.then("a discount should be applied");
    });
  });
});
```

## What the report renders

```markdown
### ✅ Eligible customer gets discount

- **Given** the customer is eligible for discounts
- **When** the customer checks out
- **Then** a discount should be applied
```
