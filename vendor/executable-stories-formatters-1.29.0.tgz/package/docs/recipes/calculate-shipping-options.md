---
title: Calculate shipping options
description: DataTable for input, multiple Then
---

One table drives the input, and three Then steps check what came back.

## The test

**Vitest**

```typescript
import { story } from 'executable-stories-vitest';
import { it } from 'vitest';

it("Calculate shipping options", ({ task }) => {
  story.init(task);
  story.given("the user has entered the shipping address");
  story.table({ label: "Address", columns: ["country", "state", "zip"], rows: [["US", "CA", "94107"]] });
  story.when("shipping options are calculated");
  story.then('the available options should include "Standard"');
  story.then('the available options should include "Express"');
  story.then("the estimated delivery date should be shown");
});
```

**Jest**

```typescript
import { story } from 'executable-stories-jest';

it("Calculate shipping options", () => {
  story.init();
  story.given("the user has entered the shipping address");
  story.table({ label: "Address", columns: ["country", "state", "zip"], rows: [["US", "CA", "94107"]] });
  story.when("shipping options are calculated");
  story.then('the available options should include "Standard"');
  story.then('the available options should include "Express"');
  story.then("the estimated delivery date should be shown");
});
```

**Playwright**

```typescript
import { test } from '@playwright/test';
import { story } from 'executable-stories-playwright';

test("Calculate shipping options", async ({}, testInfo) => {
  story.init(testInfo);
  story.given("the user has entered the shipping address");
  story.table({ label: "Address", columns: ["country", "state", "zip"], rows: [["US", "CA", "94107"]] });
  story.when("shipping options are calculated");
  story.then('the available options should include "Standard"');
  story.then('the available options should include "Express"');
  story.then("the estimated delivery date should be shown");
});
```

**Cypress**

```typescript
import { story } from 'executable-stories-cypress';

it("Calculate shipping options", () => {
  story.init();
  story.given("the user has entered the shipping address");
  story.table({ label: "Address", columns: ["country", "state", "zip"], rows: [["US", "CA", "94107"]] });
  story.when("shipping options are calculated");
  story.then('the available options should include "Standard"');
  story.then('the available options should include "Express"');
  story.then("the estimated delivery date should be shown");
});
```

## What the report renders

```markdown
### ✅ Calculate shipping options

- **Given** the user has entered the shipping address
    **Address**
    | country | state | zip |
    | --- | --- | --- |
    | US | CA | 94107 |
- **When** shipping options are calculated
- **Then** the available options should include "Standard"
- **And** the available options should include "Express"
- **And** the estimated delivery date should be shown
```
