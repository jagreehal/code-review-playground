---
title: Import users and send welcome email
description: DataTable + DocString (doc.table and doc.code)
---

One step carries a table, the next carries a code block.

## The test

**Vitest**

```typescript
import { story } from 'executable-stories-vitest';
import { it } from 'vitest';

it("Import users and send welcome email", ({ task }) => {
  story.init(task);
  story.given("the following users are to be imported");
  story.table({
    label: "Users",
    columns: ["email", "name"],
    rows: [
      ["a@example.com", "Alice"],
      ["b@example.com", "Bob"],
    ],
  });
  story.and("the email template is");
  story.code({
    label: "Template",
    content: `Welcome {{name}}!\nThanks for joining.`,
  });
  story.when("the import job runs");
  story.then("the users should exist");
  story.then("welcome emails should be sent");
});
```

**Jest**

```typescript
import { story } from 'executable-stories-jest';

it("Import users and send welcome email", () => {
  story.init();
  story.given("the following users are to be imported");
  story.table({
    label: "Users",
    columns: ["email", "name"],
    rows: [
      ["a@example.com", "Alice"],
      ["b@example.com", "Bob"],
    ],
  });
  story.and("the email template is");
  story.code({
    label: "Template",
    content: `Welcome {{name}}!\nThanks for joining.`,
  });
  story.when("the import job runs");
  story.then("the users should exist");
  story.then("welcome emails should be sent");
});
```

**Playwright**

```typescript
import { test } from '@playwright/test';
import { story } from 'executable-stories-playwright';

test("Import users and send welcome email", async ({}, testInfo) => {
  story.init(testInfo);
  story.given("the following users are to be imported");
  story.table({
    label: "Users",
    columns: ["email", "name"],
    rows: [
      ["a@example.com", "Alice"],
      ["b@example.com", "Bob"],
    ],
  });
  story.and("the email template is");
  story.code({
    label: "Template",
    content: `Welcome {{name}}!\nThanks for joining.`,
  });
  story.when("the import job runs");
  story.then("the users should exist");
  story.then("welcome emails should be sent");
});
```

**Cypress**

```typescript
import { story } from 'executable-stories-cypress';

it("Import users and send welcome email", () => {
  story.init();
  story.given("the following users are to be imported");
  story.table({
    label: "Users",
    columns: ["email", "name"],
    rows: [
      ["a@example.com", "Alice"],
      ["b@example.com", "Bob"],
    ],
  });
  story.and("the email template is");
  story.code({
    label: "Template",
    content: `Welcome {{name}}!\nThanks for joining.`,
  });
  story.when("the import job runs");
  story.then("the users should exist");
  story.then("welcome emails should be sent");
});
```

## What the report renders

```markdown
### ✅ Import users and send welcome email

- **Given** the following users are to be imported
    **Users**
    | email | name |
    | --- | --- |
    | a@example.com | Alice |
    | b@example.com | Bob |
- **And** the email template is
    **Template**
    ```
    Welcome {{name}}!
    Thanks for joining.
    ```
- **When** the import job runs
- **Then** the users should exist
- **And** welcome emails should be sent
```
