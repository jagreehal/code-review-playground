---
title: Payment declined
description: Negative path with Then and But
---

Then states what happened. But states what did not.

## The test

**Vitest**

```typescript
import { story } from 'executable-stories-vitest';
import { it } from 'vitest';

it("Payment declined", ({ task }) => {
  story.init(task);
  story.given("the user is on the checkout page");
  story.when("the user submits a declined card");
  story.then("the payment should be declined");
  story.then('the user should see "Payment failed"');
  story.but("the order should not be created");
});
```

**Jest**

```typescript
import { story } from 'executable-stories-jest';

it("Payment declined", () => {
  story.init();
  story.given("the user is on the checkout page");
  story.when("the user submits a declined card");
  story.then("the payment should be declined");
  story.then('the user should see "Payment failed"');
  story.but("the order should not be created");
});
```

**Playwright**

```typescript
import { test } from '@playwright/test';
import { story } from 'executable-stories-playwright';

test("Payment declined", async ({}, testInfo) => {
  story.init(testInfo);
  story.given("the user is on the checkout page");
  story.when("the user submits a declined card");
  story.then("the payment should be declined");
  story.then('the user should see "Payment failed"');
  story.but("the order should not be created");
});
```

**Cypress**

```typescript
import { story } from 'executable-stories-cypress';

it("Payment declined", () => {
  story.init();
  story.given("the user is on the checkout page");
  story.when("the user submits a declined card");
  story.then("the payment should be declined");
  story.then('the user should see "Payment failed"');
  story.but("the order should not be created");
});
```

## What the report renders

```markdown
### ✅ Payment declined

- **Given** the user is on the checkout page
- **When** the user submits a declined card
- **Then** the payment should be declined
- **And** the user should see "Payment failed"
- **But** the order should not be created
```
