---
title: User updates profile details
description: Single Given, multiple When, single Then
---

One Given, several When steps, one Then.

## The test

**Vitest**

```typescript
import { story } from 'executable-stories-vitest';
import { it } from 'vitest';

it("User updates profile details", ({ task }) => {
  story.init(task);
  story.given("the user is logged in");
  story.when("the user changes their display name");
  story.when("the user changes their time zone");
  story.when("the user saves the profile");
  story.then("the profile should show the updated details");
});
```

**Jest**

```typescript
import { story } from 'executable-stories-jest';

it("User updates profile details", () => {
  story.init();
  story.given("the user is logged in");
  story.when("the user changes their display name");
  story.when("the user changes their time zone");
  story.when("the user saves the profile");
  story.then("the profile should show the updated details");
});
```

**Playwright**

```typescript
import { test } from '@playwright/test';
import { story } from 'executable-stories-playwright';

test("User updates profile details", async ({}, testInfo) => {
  story.init(testInfo);
  story.given("the user is logged in");
  story.when("the user changes their display name");
  story.when("the user changes their time zone");
  story.when("the user saves the profile");
  story.then("the profile should show the updated details");
});
```

**Cypress**

```typescript
import { story } from 'executable-stories-cypress';

it("User updates profile details", () => {
  story.init();
  story.given("the user is logged in");
  story.when("the user changes their display name");
  story.when("the user changes their time zone");
  story.when("the user saves the profile");
  story.then("the profile should show the updated details");
});
```

## What the report renders

```markdown
### ✅ User updates profile details

- **Given** the user is logged in
- **When** the user changes their display name
- **And** the user changes their time zone
- **And** the user saves the profile
- **Then** the profile should show the updated details
```
