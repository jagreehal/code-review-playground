---
title: Login works
description: Story with tags
---

Tag a scenario at init so readers can filter the report by `smoke` or `auth`.

## The test

**Vitest**

```typescript
import { story } from 'executable-stories-vitest';
import { it } from 'vitest';

it("Login works", ({ task }) => {
  story.init(task, { tags: ["smoke", "auth"] });
  story.given("the user is on the login page");
  story.when("the user logs in with valid credentials");
  story.then("the user should be logged in");
});
```

**Jest**

```typescript
import { story } from 'executable-stories-jest';

it("Login works", () => {
  story.init({ tags: ["smoke", "auth"] });
  story.given("the user is on the login page");
  story.when("the user logs in with valid credentials");
  story.then("the user should be logged in");
});
```

**Playwright**

```typescript
import { test } from '@playwright/test';
import { story } from 'executable-stories-playwright';

test("Login works", async ({}, testInfo) => {
  story.init(testInfo, { tags: ["smoke", "auth"] });
  story.given("the user is on the login page");
  story.when("the user logs in with valid credentials");
  story.then("the user should be logged in");
});
```

**Cypress**

```typescript
import { story } from 'executable-stories-cypress';

it("Login works", () => {
  story.init({ tags: ["smoke", "auth"] });
  story.given("the user is on the login page");
  story.when("the user logs in with valid credentials");
  story.then("the user should be logged in");
});
```

**Go**

```go
import (
    "testing"
    es "github.com/jagreehal/executable-stories/packages/executable-stories-go"
)

func TestLoginWorks(t *testing.T) {
    s := es.Init(t, "Login works", es.WithTags("smoke", "auth"))
    s.Given("the user is on the login page")
    s.When("the user logs in with valid credentials")
    s.Then("the user should be logged in")
}
```

**Python**

```python
from executable_stories import story

def test_login_works():
    story.init("Login works", tags=["smoke", "auth"])
    story.given("the user is on the login page")
    story.when("the user logs in with valid credentials")
    story.then("the user should be logged in")
```

**Rust**

```rust
use executable_stories::Story;

#[test]
fn test_login_works() {
    let mut s = Story::new("Login works").with_tags(&["smoke", "auth"]);
    s.given("the user is on the login page");
    s.when("the user logs in with valid credentials");
    s.then("the user should be logged in");
}
```

**Kotlin**

```kotlin
import dev.executablestories.junit5.Story
import org.junit.jupiter.api.Test

class LoginTest {
    @Test
    fun `login works`() {
        Story.init("Login works", "smoke", "auth")
        Story.given("the user is on the login page")
        Story.`when`("the user logs in with valid credentials")
        Story.then("the user should be logged in")
    }
}
```

**C#**

```csharp
using ExecutableStories.Xunit;
using Xunit;

public class LoginTests : IDisposable
{
    [Fact]
    public void LoginWorks()
    {
        Story.Init("Login works", "smoke", "auth");
        Story.Given("the user is on the login page");
        Story.When("the user logs in with valid credentials");
        Story.Then("the user should be logged in");
    }
}
```

## What the report renders

```markdown
### ✅ Login works
Tags: `smoke`, `auth`

- **Given** the user is on the login page
- **When** the user logs in with valid credentials
- **Then** the user should be logged in
```
