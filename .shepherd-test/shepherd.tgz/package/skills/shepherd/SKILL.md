---
name: shepherd
description: >
  Drives a PR to merge-ready in one iteration: review rounds (swarm, triage,
  simplify) until they converge, CI repair, then the gate verdict. Starts every
  runner on the cheapest model the harness can dispatch and validates risky
  changes one rung up. Use for "/shepherd", "babysit this PR", "get this PR
  ready", or wrap in "/loop 5m /shepherd <pr>" for hands-off cadence. With
  --local, reviews and fixes your change before any PR exists.
---

# Shepherd

Owns the loop; the sub-skills own the work:

- **`swarm`** reviews and posts comments.
- **`triage`** ends every review thread fixed, resolved, or deferred.
- **simplify** tidies the diff: one runner applying the `review-simplicity`
  lens in fix mode.
- **`ci-repair`** keeps the branch current and repairs CI.
- **`gate`**, if the repo runs it, gives the approval verdict.

Swarm, triage, and simplify run together in the **quality loop** so a fix from
round 1 is reviewed again in round 2. Shepherd decides; it defers to the user
only what is genuinely theirs.

**One invocation is one iteration.** It never sleeps or loops itself. State
passes between iterations through `$ARGUMENTS` or the conversation.

## Where to run it

Cost is calls times context: every runner's result lands in this loop's
context. Run it in a session that did **not** just write the code. If you are
at the tail of the implementation session, say so and offer a fresh session or
a top-level subagent.

## Local mode

`/shepherd --local` gets a change into shape before a PR exists: review, fix,
run the checks, repeat, until a round is clean or a decision needs the
developer. Same lenses, same verification, same fix rules. It runs on this
machine and stops there:

- **No GitHub writes and no GitHub reads.** No push, no comment, no thread, no
  commit status, no gate. Steps 3 to 5 do not run.
- **No commits.** Fixes land in the working tree; the developer reviews and
  commits them. If the tree has a merge or rebase in progress, stop and say so.
- **The fix mode decides the steps.** Under `fixes.mode: suggest`, run one
  round of swarm only, with no triage and no simplify, and report `reviewed`
  with the findings. Under `local` or `push`, run the loop below.

One local iteration:

```
L0  shepherd local change                 -> fingerprint, patch_path, ranges
    rounds r = 1..4, stop on a clean round
      swarm --local at the current change   (record, finish)
      triage in local mode on its record    (edits the working tree)
      simplify, when warranted              (edits the working tree)
      shepherd local change                 -> the next round's change
```

- Pass swarm `--local` (with `--base <ref>` when the developer gave one; pass
  it to every `shepherd local` call too) and the ladder; pass triage `findings_path` from swarm's
  `local` result. Run simplify on the same gate as Step 2c, with
  `review_base_sha` set to the capture's `base_sha`.
- **A round is clean** when swarm's `local.status` is `complete`, its checks
  ran without a failure on changed lines, triage fixed and promoted nothing,
  and simplify changed nothing. A check the repository configures that was
  skipped (`checks skipped: <tool> (<reason>)`) did not run, so its round is
  not clean: report it. A finding triage dismissed with a reason does not
  block a clean round; a deferred one ends the loop for the developer,
  after one more swarm whenever triage fixed anything that round. Never stop
  with fixes no review has seen: the report's `shepherd local status` must say
  `reviewed` for the files as they are now.
- **Incomplete is not clean.** When `finish` says `incomplete`, retry the
  missing lens or stage once; still incomplete, stop and list what was not
  reviewed.
- Validation requests go through `references/dispatch.md` as on a PR.

Report one of these, with the round count, the fixes by file, and every
deferred finding with its options:

- **local checks passed:** the last round was clean and `shepherd local
  status` says `reviewed` for the files as they are now. Merge readiness still
  belongs to the PR workflow; offer to open the PR (body as in Step 1's "No
  PR") and run `/shepherd <pr>`.
- **needs you:** findings were deferred, or checks still fail.
- **review incomplete:** what was not reviewed, and why.
- **stopped at the round cap:** what the last round still found, and a request
  to reconsider the approach before running again.

## Handoff mode

When `SHEPHERD_HANDOFF` names a directory, this session holds no push
credential: the CI workflow (`templates/shepherd.yml`) runs the model with a
token that can comment and read but not write code, and a later job with no
model pushes what you hand it. An iteration then differs in six places:

- **Swarm hands its round off instead of posting it.** Write the round JSON
  (swarm's `references/formats.md`) to `$SHEPHERD_HANDOFF/round.json` and post
  neither the inline review nor the summary: the publish job, which runs no
  model, renders both with `shepherd inline` and `shepherd summary` and posts
  them, the summary carrying on the round number of the one already on the PR.
  A model that wrote review Markdown itself once posted bare comments with no
  header, title or prompt. Under `suggest` the review is the whole output: a
  run that ends with findings and no `round.json` has failed. Threads still
  resolve and triage still runs with the job's token as before. Never comment
  `/shepherd` or run `shepherd review`: that asks the workflow to run you again.

- **Commit, never push.** Commit on the PR branch as usual. Append the handoff
  addition from `references/dispatch.md` to every runner brief. After a runner,
  the remote head must still be `H0` and your local HEAD is its
  `new_head_sha`; a remote that moved means someone pushed, so stop and
  re-baseline next iteration.
- **One quality round.** Swarm posts inline comments on lines GitHub has, so it
  cannot review commits that are not pushed yet. Run round 1 and stop the loop;
  the push starts CI, and CI finishing starts the next iteration, which reviews
  these commits.
- **No thread resolves on an unpushed fix.** The next iteration's triage sees
  the pushed fix and resolves the thread then.
- **Step 4 runs only when HEAD is still `H0`.** Otherwise the gate has nothing to
  judge until the push; report `pending`.
- **Step 5 writes the status for the workflow to set.** Never call the
  statuses API or run `shepherd notify`: the job's token cannot set a status,
  and the call fails with 403. Write `$SHEPHERD_HANDOFF/status.json` with your file tool:
  `{"state": "<success|pending|failure>", "description": "<the line>"}`, and
  each job id ci-repair wants rerun on its own line in
  `$SHEPHERD_HANDOFF/rerun-jobs.txt`. The publish job pushes your commits,
  sets the status on the head it pushed (`pending` whenever it pushed: those
  commits are not reviewed yet; with nothing pushed or rerun, `failure` in
  place of `pending` when the round has findings above NIT), reruns the jobs,
  and notifies. It refuses a
  push that is not a fast-forward of `H0` or that touches a protected path
  (workflows, hooks, package manager config, manifests, lockfiles), and sets
  `failure` naming why.

Done when every commit is on the local PR branch and `status.json` exists.

## Team policy and recipes

Load the team policy once, as `references/policy.md` says, and pass it to
every runner. Then pick the workflow:

- `--recipe <name>`: that recipe's steps, under the rules there. An unknown
  name stops with the list of known ones; one the fix mode rules out stops
  with the reason.
- No `--recipe`, by `fixes.mode`:
  - `push`: the loop below, Steps 1 to 5 (the `pr` recipe).
  - `local`: the `fix` recipe (swarm, triage, simplify, swarm) with fixes
    left in the working tree; Steps 3 and 4 do not run.
  - `suggest`: the `review` recipe (swarm only); no step changes code.

End a recipe with the outcome policy.md defines (`reviewed`,
`fixes_uncommitted`, `ready`, `pending`); never call a PR ready on less.

## Before the first dispatch

Read these once per iteration, when first needed:

| File | When |
|---|---|
| `references/models.md` | now: resolve the model ladder |
| `references/dispatch.md` | before the first sub-skill dispatch |
| `references/degradation.md` | when something is missing or failing |
| `references/formats.md` | at Step 5, or when unsure of narration |

Read the policy with `shepherd config explain --json`, and any other file
under `.shepherd/` or `.github/` with `git show origin/<default>:<path>` or
`git cat-file -e`. Never glob or search for them: a glob can skip
dot-directories and report nothing there.

Also establish how commits land. Some harnesses require signed commits and
block `git commit` / `git push` in favour of their own tool. Find out now and
name the working mechanism in every brief that may commit.

## State between iterations

This skill owns all of it; runners receive what they need and return updates.

- `swarm_marker_sha`: HEAD when swarm last ran. `null` at first.
- `simplify_marker_sha`: HEAD when simplify last ran. `null` at first.
- `gate_applied_for_sha`: HEAD when the gate label was last applied. `null` at first.
- `deferred_threads`: thread ids already surfaced to the user.
- `last_updated_at`: the PR's `updatedAt` at the end of the last iteration.
- `bot_reviews_pending`: set when this skill marks a draft ready.

## Shepherd's commits are not the author's decisions

Every commit shepherd or a runner makes carries a `Shepherd: <skill>` trailer:
review fixes, simplify passes, reverts, base merges it starts. They post under
the author's account, so without the trailer a later run reads shepherd's own
choice (a revert, a deferral) as the author's intent. When reasoning about what
the author decided, read only commits without the trailer, and threads the
author wrote. A thread an earlier run deferred is still open work for this run.

## HEAD threading

Every round can move HEAD, and the gate keys off the final one:

```
H0 = Step 1 HEAD
Step 2  rounds r = 1..N (N <= 4, stop on a dry round)
          swarm when warranted, at H(r).0   (comments only; HEAD unchanged)
          triage(head_sha_in = H(r).0)     -> H(r).1
          simplify when warranted, at H(r).1; commit + push if it changed files -> H(r).final
        H1 = last round's final HEAD
Step 3  ci-repair(head_sha_in = H1)        -> H2
Step 4  gate at H2
```

Passing `H0` to ci-repair would diagnose a stale tree. Thread it.

## Trace the iteration

Around each stage, record its start and end so the iteration can be traced. The
CLI takes the time; you name the stage, and an `end` repeats its start's
`--round`:

```bash
shepherd trace event <stage> start --pr <n> [--round <r>] [--head <sha>]
shepherd trace event <stage> end   --pr <n> [--round <r>] [--outcome ok|failed|skipped] [--retries <n>]
```

Run the CLI as swarm does: `shepherd`, or `bunx @jagreehal/shepherd` when it
is not on PATH. Local mode has no PR, so it records no trace.

Stages: `checks`, `swarm`, `verify`, `triage`, `simplify`, `ci-repair`, and
`gate` for the wait on the gate's verdict. Step 5 flushes the record. A failed
`trace` call never stops the loop; note it and go on. Without an
`OTEL_EXPORTER_OTLP_ENDPOINT` the flush exports nothing and only clears the
record, so recording costs nothing where nobody collects traces.

## Step 1: Resolve the PR, fast path, baseline

```bash
gh pr view --json number,url,baseRefName,headRefOid,state,isDraft,updatedAt,labels \
  --jq '{number, url, base: .baseRefName, head_sha: .headRefOid, state, isDraft, updatedAt, labels: [.labels[].name]}'
```

Take owner/repo from `url`. Merged or closed: stop with a final summary.

**Fast path.** On a re-invocation where HEAD and `updatedAt` both match the
carried state and the gate needs nothing, check
`gh pr checks <number> --json name,state,bucket,workflow` (CI changes do not
bump `updatedAt`; `bucket` is `pass`, `fail`, `pending`, `skipping` or `cancel`). Skip the iteration only if nothing fails. Narrate the skip,
print the state line, and hand back.

**Draft.** Invoking shepherd says the PR is ready: `gh pr ready <number>`. That
also wakes the repo's review bots, which take minutes; set
`bot_reviews_pending = true` so round 1 does not mistake silence for a clean PR.

**No PR.** Ask the user (`AskUserQuestion`): review the change locally first
(local mode, above), paste a PR, let shepherd open one with `gh pr create`
(write the body with the repo's PR-description skill if it has one, else
with `../pr/SKILL.md`), or
cancel.

A body shepherd writes starts with
`> <img src="https://raw.githubusercontent.com/jagreehal/shepherd/main/docs/public/favicon.png" alt="🤖" width="16" height="16"> Written by an AI agent on behalf of @<login>, who has not reviewed it yet.`
Only the author changes that line: a green `shepherd` status is no person's
reading of the code. Its evidence holds to these rules:

- "Before" comes from the base branch, never a reverted copy of the change.
- Demo or sanitised data only.
- One line says what was not tested or run.
- A security fix on a public repository keeps its description short: no exploit
  or reproduction until the fix is released.

**Be on the PR branch.** Every runner commits to it from this tree. If the
tree has uncommitted changes, stop and ask; never stash or discard them.
Otherwise `gh pr checkout <number>`, `git pull --ff-only`, and confirm
`git rev-parse HEAD` equals `H0`. Tell every runner the tree is the author's
own PR head. On a PR by someone other than the logged-in user, confirm with
`AskUserQuestion` before the first push to their branch.

**Check the base, then write the diff once** for the round. Run
`shepherd stack <number>`; it prints JSON from git ancestry alone:

- `wrong_base` set: most of the PR's commits already sit on another long-lived
  branch, so the diff is mostly other people's merged work. Review nothing. Set
  the `shepherd` status to `failure` with "retarget to `<branch>`: `<on>` of
  `<total>` commits are already there (`gh pr edit <number> --base <branch>`)",
  report the same line, and stop.
- `parent` set: the PR is stacked on open PR `#<parent.number>` into the same
  base. Review only this PR's change: write
  `git diff <range>` (the delta over the parent's head) as the round's patch and
  pass `stacked_on: <parent.number>` to swarm and triage. The parent's code is
  reviewed in the parent's PR. The gate holds its approval until the parent is
  approved on its current head, so a stacked PR finishes `pending`, "waiting on
  #<parent>", until then.
- Neither, or the command exits non-zero: `gh pr diff <number>`. On an error,
  name it in the round's summary.

Write the patch to `"$(git rev-parse --git-common-dir)/shepherd/<short_sha>.patch"`
(create the directory first) and pass the path. The repo's git directory is the
same path for every process and never committed; `$TMPDIR` can differ inside
and outside a sandbox.

## Step 2: Quality loop

Run rounds until one is **dry**, at most 4. Usually that means at least 2, so
round 1's fixes get reviewed. The exception: round 1 is dry and swarm ran in
it; stop at 1 and say so.

**a. swarm, when warranted.** Run it when `swarm_marker_sha` is `null`, or
HEAD moved and `swarm_marker_sha..HEAD` changes something besides `*.md`,
`*.txt`, whitespace, or comments. A head reached only by merging the base
changes nothing to review: when the PR's diff (`gh pr diff`) has the same
`git patch-id --verbatim < <patch>` as the one swarm last reviewed, skip swarm
and move `swarm_marker_sha` to HEAD. The patch id ignores the line numbers and
blob ids a base merge shifts, and keeps whitespace. Keep each round's patch
under the git directory so the comparison needs no fetch. Without a stored
patch to compare, or when either id is empty, run swarm. Swarm runs **in this loop** (from `../swarm/SKILL.md`):
follow its steps yourself and start no agent to run it. Its first wave starts
the router and every lens in one parallel dispatch from this session; inside
a sub-agent those reviewers nest or never start. Pass the PR number, the
diff path, the resolved ladder and `models` pins, HEAD, and `since_sha = swarm_marker_sha` when it
is set. Set `swarm_marker_sha = HEAD` after.
Skipping it despite qualifying changes needs an `AskUserQuestion` confirm, in
round 1 only.

**b. triage.** When the unresolved-thread query (triage's Step 3) returns
nothing, the gate raised no issues on the head, and no validation request is
pending, record triage as a no-op for the round without dispatching. An empty
input is not a skipped step. Otherwise, one runner at the second rung (see dispatch). Relay its
narration with the round number. Record `new_head_sha`, `deferred_threads`, the
counts, `gate`, and any `validation_requests`, which go through the validation
flow in `references/dispatch.md` before the round can be dry.

Check triage's result against GitHub before trusting it: re-run the thread
query, and any thread it reported actioned or resolved that is still open goes
back to a triage runner one rung up, scoped to those threads. Cheap runners fix
code and forget to resolve, or commit and forget to push.

Shepherd never acts on a thread itself. A thread a runner deferred stays
deferred for the user, even when the loop disagrees; say so in the summary
instead of applying the change.

After every runner that reports a new head, check the remote agrees:
`gh pr view <number> --json headRefOid -q .headRefOid` must equal
`new_head_sha`. A commit the runner made but did not push is pushed now, and the
discrepancy goes in the summary; any other mismatch means someone else pushed,
so stop the round and re-baseline next iteration.

**c. simplify, when warranted.** Same gate as swarm, keyed on
`simplify_marker_sha`, and skipped when the PR adds fewer than about 20 lines:
there is too little for a pass to find. Neither skip is a degradation. One runner edits the working tree without committing.
Its brief carries the first head of this iteration as `review_base_sha` and
every deferred thread's `file:line`, so it cannot undo a review fix or decide a
deferred question.
Confirm its claimed changes with `git status --porcelain` in your own tree;
then `git add`, commit `refactor: simplify pass` with the trailer
`Shepherd: simplify`, push. Set `simplify_marker_sha = HEAD`.

**d. Keep the PR description true.** Review fixes change behaviour the
description may not mention, and the gate refuses undisclosed behaviour in risky
territory. When this round's commits changed what the code accepts, returns,
throws, or writes, upsert one section at the end of the PR body, between
`<!-- shepherd:review-changes -->` markers, headed "Changes made during review"
with one line per behaviour change, its commit, and the test that covers it. Re-check the lines already
there against the head: correct or drop one a later commit undid, so the
section never claims a change the code no longer makes. Edit only that section;
the rest of the body is the author's. `gh pr view --json body`, then
`gh pr edit <number> --body-file <file>`.

**e. Dry?** A round is dry when triage actioned, resolved, and promoted nothing,
added no deferred thread, simplify changed nothing, no validation request is
pending, no lens in swarm's result has `status: failed`, and
`bot_reviews_pending` is false. A failed lens did not review its scope, so the
next round retries it. A lens that `could_not_run` (its skill does not resolve)
will not fix itself: it does not block a dry round, and the final summary names
it as unreviewed.

While `bot_reviews_pending` is true, poll once before the next triage:
`gh pr view <number> --json latestReviews --jq '[.latestReviews[].author.login]'`.
Nothing yet: wait about 90 seconds, poll once more, then clear the flag either
way. When the head has a **Claude Code Review** check run, its status and
title replace the guess:

```bash
gh api 'repos/<owner>/<repo>/commits/<head_sha>/check-runs?check_name=Claude%20Code%20Review' \
  --jq '.check_runs[] | {status, conclusion, title: .output.title}'
```

- `queued` or `in_progress`: the review is running. Poll it the same way, and
  clear the flag once it completes.
- Completed with findings or "found no issues": triage reads its threads.
- "skipped — no new changes": the review of the earlier head stands.
- A `conclusion` of `failure`, `timed_out` or `cancelled`, a title saying
  "failed", "timed out" or "declined", or a PR comment starting `⚠️ Code
  review skipped` (its budget ran out): Code Review did not review this head.
  Clear the flag, read its silence as no review, and name it in the final
  summary. Shepherd posts no `@claude review`, since each one starts a billed
  review; the summary tells the user they can.

Poll inline, in this turn. Never hand a wait to a background agent or a
monitor: nothing reports back, and the iteration strands.

- Dry, and `r >= 2` or swarm ran this round: stop; this round's final HEAD is `H1`.
- `r == 4`: stop, narrate the cap, use this round's final HEAD as `H1`, and
  report `stopped=round-cap`. Run every runner in every round the loop reaches;
  skipping one is a degradation and goes in the summary. A no-op on empty input
(see b) is not a skip.
- Otherwise run the next round from this round's final HEAD.

## Step 3: ci-repair

When no check is failing, the branch is 0 commits behind its base, and no CI
summary comment carries a warning (all cheap to read: `gh pr checks`,
`git rev-list --count HEAD..origin/<base>`, the PR's bot comments), record ci-repair as a no-op without dispatching; `H2 = H1`. Otherwise, one
runner at the second rung with `head_sha_in = H1`. Relay its narration.
Record `new_head_sha` as `H2`. Check the result's shape: `ci` must carry
`pass/pending/fail/failing` and `base_update.status` must be `updated`,
`resolved`, `current`, `behind`, or `conflict` (`behind`: the fix mode kept it
from updating the branch). Any `validation_requests` go through the validation
step, as triage's do. A malformed result means the runner skipped the real
steps; reissue it one rung up rather than accept it.

A base conflict is surfaced in one line and Step 4 still runs: it blocks the
merge, not the review.

`resolved` means ci-repair merged the base and settled a conflict, which changed
the PR's own diff. Nothing has reviewed that yet: this iteration ends `pending`,
and the next one's swarm reviews it, whatever the gate says about `H2`. When the
resolution changed behaviour, add it to Step 2d's section.

## Step 4: gate

Skip this step with `gate=absent` when the repo has no gate workflow on the
default branch. Check with `git cat-file -e
origin/<default>:.github/workflows/shepherd.yml`, never a glob or a file search:
those can skip `.github/`, and a missed gate reads as `absent`.

Guard first:

```bash
gh pr view <number> --json isDraft,headRefOid
```

- `headRefOid != H2`: someone pushed under you. Skip; the next iteration re-baselines.
- Draft: mark ready; the review skips drafts, and the check reads `not reviewed: PR is a draft`.

**Label mode** (the gate policy sets `label:`): when
`gate_applied_for_sha != H2`, `gh pr edit <number> --add-label <label>` and set
`gate_applied_for_sha = H2`. **All-PRs mode:** the gate runs on every push; there
is nothing to apply.

Read the verdict every time from the `shepherd` check on `H2`, the head you
pushed. The check carries the review's verdict; every review posts as a COMMENT.

```bash
gh api "repos/{owner}/{repo}/commits/<H2>/statuses" \
  --jq '[.[] | select(.context == "shepherd")][0] | {state, description}'
```

- `pending`: a review is queued or running. `not reviewed: …` means the PR is a
  draft or lacks the label; mark it ready or apply the label.
- `success`: report `approved` with the description (`approved; no open
  thread`, or `approved by <person>` after an escalation).
- `failure`: `changes needed: …` is `refused`; `a person decides: …` is
  `escalate`; `approved; N open thread(s) to resolve` is `pending` until those
  threads are resolved. For the reasons behind a refusal or an escalation, read the
  newest review whose body contains `<!-- gate-run:`, capped so a full body
  never enters context:

  ```bash
  gh pr view <number> --json latestReviews \
    --jq '[.latestReviews[] | select(.body | contains("<!-- gate-run:")) | .body[:1200]][0]'
  ```
- `error`: the review did not finish. Comment `/review` once per head.
- No status on `H2`, and `gh run list --workflow shepherd.yml --commit <H2>`
  shows no run or only cancelled and skipped ones: nothing will review `H2` on
  its own. Ask once per head, when `gate_applied_for_sha != H2`: in label mode
  remove and re-add the label; in all-PRs mode comment `/review` followed by the
  header on its own lines (the workflow reads only the first line). Set
  `gate_applied_for_sha = H2` and report `pending`.

Never report an older head's verdict as current.

Report approved, refused, escalate, or pending, with the one-line reason. A base
merge is a push, so the review runs again on the new head. Never try to get
around the gate.

## Step 5: Status, summary and hand-back

Set the `shepherd` commit status on `H2`, every iteration, so the PR shows
where the loop got to even after this session ends. Green CI must never read
as "done" while shepherd still has work or is waiting on the author. In
handoff mode, write `$SHEPHERD_HANDOFF/status.json` instead and skip this
command (Handoff mode, above):

```bash
gh api "repos/<owner>/<repo>/statuses/<H2>" -f context=shepherd \
  -f state=<success|pending|failure> -f description="<one line, under 140 characters>"
```

Before setting `success`, read the people's verdicts. Branch protection enforces
a person's "changes requested" only where it requires reviews, and it arrives as
a review body that no thread carries, so triage never sees it:

```bash
gh api "repos/<owner>/<repo>/pulls/<number>/reviews?per_page=100" --paginate | jq -s 'add // [] | map(select(.user != null and .user.type != "Bot" and (.state == "APPROVED" or .state == "CHANGES_REQUESTED" or .state == "DISMISSED"))) | group_by(.user.login) | map(last | select(.state == "CHANGES_REQUESTED") | .user.login)'
```

It lists each person whose latest verdict is still "changes requested". A later
approval or dismissal clears one; a comment does not. Only the account type
excludes a review, never its body: anyone can paste a marker. A gate posting
through a person's token counts like that person until its own later approval
clears it.

Then close the iteration's trace, naming how it ended (the summary's
`stopped=`, or `waiting` or `needs-you`), the CI run the iteration read, and
any traceparent another process exposed (the gate's review run, a CI run) so the
traces join by span link:

```bash
shepherd trace flush --pr <n> --repo <owner/repo> --head <H2> --base <base_sha> \
  --outcome <how it ended> [--ci-run <id> --ci-attempt <n>] [--related <traceparent>]...
```

- `success`: the second terminal condition holds and nothing is deferred:
  the gate approved `H2` (or the repo has no gate), CI is green, no unresolved
  thread is left, and no person's latest review requests changes.
- `failure`: the loop can do nothing more on its own (the "needs the author"
  terminal condition below). The description says what is needed, most
  important first: `gate refused: <reason>`, `gate escalated`, `changes
  requested by <login>`, `3 threads need you`, `base conflict`. A loop that
  stopped at its cap adds `round cap: reconsider the approach`.
- `pending`: anything else: work remains, the gate has not judged `H2`, or bot
  reviews are on their way.

Then tell people, when the repo has opted in. Write the same description to a
file with your file tool (it can quote PR text, so it never goes in a command)
and run:

```bash
shepherd notify --pr <n> --repo <owner/repo> --head <H2> --state <same state> --file <that file>
```

It does nothing unless `SHEPHERD_NOTIFY_WEBHOOK` is set, posts only when the
state or description changed since the last call for this PR, and never fails
the iteration. Run it every iteration; it does the deduplication.

A session that dies mid-iteration leaves the last `pending`, never a green.
A push that shepherd did not make lands on a head with no `shepherd` status,
so a branch rule that requires it blocks the merge until shepherd runs again.
If posting the status fails, say so in the summary and carry on.

Then print the iteration summary and the state line (`references/formats.md`),
and hand back. For cadence: `/loop 5m /shepherd <pr>`.

## Step 6: Reflect (terminal conditions only)

At the final stop only, from what is already in context: did following this
skill cost more, or achieve less, than it should have? Each of these is a defect
in the skill:

- a sub-skill was missing or half-loaded and the loop ran degraded
- a runner ran on a costlier model than the ladder intended
- the quality loop hit the round cap without converging
- the same work happened twice (a file re-read, a diff re-fetched)
- an instruction was ambiguous and the guess was wrong
- a deferred thread the user settled in one line, or an auto-fix they reverted
- a runner spent turns finding out how this repo works (a setup step, the right
  test command, a gotcha) that one line in `AGENTS.md` would have told it

None fired: say `[shepherd] reflect — nothing to change` and stop. Otherwise give
the user what happened, which instruction allowed it, and the smallest edit to
this skill that would prevent it. Offer the edit; never apply it unasked.

## Terminal conditions

Stop for good when:

- the PR is merged or closed;
- The gate has approved the current head (or the repo has no gate), CI has no
  failure needing autonomous work, no new bot threads arrived, and every
  unresolved thread is in `deferred_threads`;
- **needs the author:** nothing autonomous is left (every unresolved thread is
  in `deferred_threads`, triage has acted on every fixable issue in the gate's
  latest refusal, ci-repair has exhausted its repairs, and the quality loop
  ended dry or at its cap), yet the gate refused or escalated `H2`, CI still
  fails, the base conflicts, or a person's review requests changes. Set the `failure` status naming what is
  needed, list it for the user, and stop: another iteration would only repeat
  this one; or
- the user interrupts.

Only the first terminal condition with nothing deferred sets `success`.
CI failures are never report-only: ci-repair must diagnose and exhaust its safe
repair or rerun first. Deferred threads never stop the loop. The round cap stops
the quality loop, not the iteration; Steps 3 and 4 still run.
